from flask import Flask, render_template, flash, redirect, url_for, session, request
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash


import joblib

import os
import numpy as np
# from PIL import Image

# Keras
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image

# Flask utils
# from flask import Flask, request, render_template
from werkzeug.utils import secure_filename
import tensorflow_hub as hub
from keras.models import load_model
import tensorflow as tf




app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)



# Load the model
model_path = 'GlaucomaModel.h5'
loaded_cnn_model = tf.keras.models.load_model(model_path)

# def model_predict(img_path, model):
#     img = image.load_img(img_path, target_size=(256, 256))
#     x = image.img_to_array(img)
#     x = np.expand_dims(x, axis=0)
#     x = x / 255.0  # Normalize the pixel values to the range [0, 1]
#     preds = model.predict(x)
#     return preds



def model_predict(img_path, model):
    # Load and resize the image
    img = image.load_img(img_path, target_size=(224, 224))
    
    # Convert the image to a numpy array
    x = image.img_to_array(img)
    
    # Expand the dimensions to match the model's expected input shape
    x = np.expand_dims(x, axis=0)
    
    # Normalize the pixel values to the range [0, 1]
    x = x / 255.0
    
    # Make predictions
    preds = model.predict(x)
    
    return preds


@app.route('/index', methods=['GET'])
def index():
    # Main page
    return render_template('index.html')



@app.route('/predict', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return render_template('result.html', error='No file part')

    file = request.files['file']

    if file.filename == '':
        return render_template('result.html', error='No selected file')

    # Save the file to ./uploads
    basepath = os.path.dirname(__file__)
    file_path = os.path.join(basepath, 'uploads', secure_filename(file.filename))
    file.save(file_path)

    # Check if the file exists
    if os.path.exists(file_path):
        # Make prediction
        preds = model_predict(file_path, loaded_cnn_model)
        print("Raw Predictions:", preds)

        disease_class = ["Non-Glaucoma", "Glaucoma"]
        predicted_labels = [disease_class[i] for i in np.argmax(preds, axis=1)]
        return render_template('result.html', predictions=predicted_labels)
    else:
        return render_template('result.html', error='File not found')

@app.route('/predict')
def predict():
    
    return render_template('predict.html')

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            flash('Login successful!', 'success')
            session['user_id'] = user.id
            return redirect(url_for('home'))
        else:
            flash('Login failed. Check your email and password.', 'danger')
    return render_template('login.html')

@app.route('/register/', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password == confirm_password:
            hashed_password = generate_password_hash(password)
            new_user = User(username=username, email=email, password=hashed_password)
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('login'))
        else:
            flash('Passwords do not match.', 'danger')

    return render_template('register.html')

@app.route('/logout/')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('home'))


@app.route('/home')
def home():
	return render_template("home.html")


@app.route('/contact')
def contact():
	return render_template("contact.html")


@app.route('/about')
def about():
	return render_template("about.html")


@app.route('/hello')
def hello():
	return render_template("index.html")


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
